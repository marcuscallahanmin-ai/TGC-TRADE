/* TGC TRADE — game layer: synthesized sounds, XP, levels, streaks, achievements, confetti */
const Game=(()=>{
const GKEY="tgc_trade_game_v1";
const reduceMotion=window.matchMedia&&matchMedia("(prefers-reduced-motion: reduce)").matches;
const ACH=[
 {id:"first_listing",icon:"🃏",name:"First Pull",desc:"Post your first listing"},
 {id:"photo",icon:"📸",name:"Shutterbug",desc:"Upload a card photo"},
 {id:"legendary",icon:"🌟",name:"Legendary Listing",desc:"Hit 100% listing power"},
 {id:"three",icon:"🎩",name:"Hat Trick",desc:"Post 3 listings"},
 {id:"ten",icon:"📚",name:"Binder Full",desc:"Post 10 listings"},
 {id:"hunter",icon:"🎯",name:"Hunter",desc:"Add a card to My Wants"},
 {id:"hype",icon:"📣",name:"Hype Master",desc:"Share a listing"},
 {id:"streak3",icon:"🔥",name:"On Fire",desc:"Visit 3 days in a row"},
 {id:"lvl5",icon:"🏆",name:"Rising Collector",desc:"Reach level 5"}
];
const TIERS=[{min:100,name:"LEGENDARY",cls:"legendary"},{min:80,name:"EPIC",cls:"epic"},{min:50,name:"RARE",cls:"rare"},{min:0,name:"COMMON",cls:"common"}];
const tierFor=p=>TIERS.find(t=>p>=t.min);
let g=load();
function load(){try{const s=JSON.parse(localStorage.getItem(GKEY)||"null");if(s)return Object.assign({xp:0,muted:false,streak:0,lastDay:"",stats:{},ach:{}},s)}catch(e){}return {xp:0,muted:false,streak:0,lastDay:"",stats:{},ach:{}}}
function save(){try{localStorage.setItem(GKEY,JSON.stringify(g))}catch(e){}}
const need=l=>100+(l-1)*60; // XP needed to go from level l to l+1
function levelInfo(xp=g.xp){let l=1,r=xp;while(r>=need(l)){r-=need(l);l++}return{level:l,into:r,span:need(l),pct:Math.round(r/need(l)*100)}}
const stat=k=>g.stats[k]||0;

/* ---------- Sound engine (Web Audio, no files) ---------- */
let ctx=null,unlocked=false;
function ac(){if(!ctx){const C=window.AudioContext||window.webkitAudioContext;if(!C)return null;ctx=new C()}return ctx}
function unlock(){const c=ac();if(!c)return;if(c.state==="suspended")c.resume();unlocked=true}
["pointerdown","keydown","touchstart"].forEach(ev=>window.addEventListener(ev,unlock,{passive:true}));
function tone(f,t0,dur,type="sine",vol=.15,slide){
 const c=ac();if(!c||!unlocked||g.muted)return;
 const o=c.createOscillator(),v=c.createGain(),t=c.currentTime+t0;
 o.type=type;o.frequency.setValueAtTime(f,t);if(slide)o.frequency.exponentialRampToValueAtTime(slide,t+dur);
 v.gain.setValueAtTime(0.0001,t);v.gain.exponentialRampToValueAtTime(vol,t+.01);v.gain.exponentialRampToValueAtTime(0.0001,t+dur);
 o.connect(v).connect(c.destination);o.start(t);o.stop(t+dur+.05);
}
function whoosh(t0=0,dur=.35,vol=.12){
 const c=ac();if(!c||!unlocked||g.muted)return;
 const n=Math.floor(c.sampleRate*dur),b=c.createBuffer(1,n,c.sampleRate),d=b.getChannelData(0);
 for(let i=0;i<n;i++)d[i]=Math.random()*2-1;
 const s=c.createBufferSource(),f=c.createBiquadFilter(),v=c.createGain(),t=c.currentTime+t0;
 s.buffer=b;f.type="bandpass";f.Q.value=1.2;f.frequency.setValueAtTime(300,t);f.frequency.exponentialRampToValueAtTime(3500,t+dur);
 v.gain.setValueAtTime(0.0001,t);v.gain.exponentialRampToValueAtTime(vol,t+dur*.4);v.gain.exponentialRampToValueAtTime(0.0001,t+dur);
 s.connect(f).connect(v).connect(c.destination);s.start(t);s.stop(t+dur);
}
const N={C5:523.25,D5:587.33,E5:659.25,G5:783.99,A5:880,B5:987.77,C6:1046.5,E6:1318.5,G6:1568,C7:2093};
const SFX={
 click(){tone(620,0,.06,"square",.06,880)},
 tick(n=0){tone(520+n*90,0,.09,"sine",.12)},
 photo(){whoosh(0,.3,.1);tone(N.B5,.18,.09,"square",.08);tone(N.E6,.26,.2,"square",.08)},
 coin(){tone(N.B5,0,.07,"square",.07);tone(N.E6,.07,.22,"square",.07)},
 xp(){tone(N.G5,0,.08,"triangle",.1);tone(N.C6,.07,.14,"triangle",.1)},
 success(){whoosh(0,.4,.1);[N.C5,N.E5,N.G5,N.C6].forEach((f,i)=>tone(f,.12+i*.08,.18,"triangle",.14));tone(N.C6,.5,.6,"square",.05);tone(N.E6,.5,.6,"triangle",.1);tone(N.G6,.5,.6,"triangle",.08)},
 legendary(){SFX.success();[N.G6,N.C7].forEach((f,i)=>tone(f,.95+i*.12,.5,"sine",.1))},
 level(){[N.C5,N.D5,N.E5,N.G5,N.C6,N.E6].forEach((f,i)=>tone(f,i*.07,.2,"square",.07));tone(N.C6,.5,.7,"triangle",.14);tone(N.G6,.5,.7,"triangle",.1)},
 achievement(){[N.E6,N.G6,N.C7].forEach((f,i)=>{tone(f,i*.1,.5,"sine",.12);tone(f*2,i*.1,.3,"sine",.03)})},
 off(){tone(440,0,.1,"sine",.08,220)},
 on(){tone(440,0,.08,"sine",.1);tone(660,.08,.12,"sine",.1)}
};
function sfx(name,...a){try{SFX[name]&&SFX[name](...a)}catch(e){}}

/* ---------- Confetti ---------- */
function confetti(count=140,origin){
 if(reduceMotion)return;
 const cv=document.createElement("canvas");cv.className="confetti";document.body.appendChild(cv);
 const W=cv.width=innerWidth,H=cv.height=innerHeight,x=cv.getContext("2d");
 const ox=origin?origin.x:W/2,oy=origin?origin.y:H*.4,cols=["#7c5cff","#21d4a4","#ffc857","#ff5d73","#5d7cff","#fff"];
 const ps=Array.from({length:count},()=>({x:ox,y:oy,vx:(Math.random()-.5)*14,vy:Math.random()*-13-3,s:5+Math.random()*7,r:Math.random()*6,vr:(Math.random()-.5)*.4,c:cols[Math.random()*cols.length|0],life:0}));
 (function frame(){x.clearRect(0,0,W,H);let alive=0;
  ps.forEach(p=>{p.vy+=.35;p.vx*=.99;p.x+=p.vx;p.y+=p.vy;p.r+=p.vr;p.life++;if(p.y<H+20){alive++;x.save();x.translate(p.x,p.y);x.rotate(p.r);x.fillStyle=p.c;x.globalAlpha=Math.max(0,1-p.life/160);x.fillRect(-p.s/2,-p.s/3,p.s,p.s*.6);x.restore()}});
  alive?requestAnimationFrame(frame):cv.remove()})();
}

/* ---------- HUD / popups ---------- */
function hud(){const L=levelInfo();return `<button class="hud-sound" onclick="Game.toggleMute()" title="Sound ${g.muted?"off":"on"}" aria-label="Toggle sound">${g.muted?"🔇":"🔊"}</button><a class="hud" href="#/profile" title="${L.into}/${L.span} XP to next level"><span class="hud-lvl">LV <b>${L.level}</b></span><span class="hud-bar"><i style="width:${L.pct}%"></i></span>${g.streak>1?`<span class="hud-streak">🔥${g.streak}</span>`:""}</a>`}
function refreshHud(){const el=document.querySelector(".hud-wrap");if(el)el.innerHTML=hud()}
function toggleMute(){if(g.muted){g.muted=false;save();unlock();sfx("on")}else{sfx("off");g.muted=true;save()}refreshHud()}
function floatText(text,cls=""){const d=document.createElement("div");d.className="float-xp "+cls;d.textContent=text;document.body.appendChild(d);setTimeout(()=>d.remove(),1600)}
function badgeToast(a){const d=document.createElement("div");d.className="ach-toast";d.innerHTML=`<span>${a.icon}</span><div><small>ACHIEVEMENT UNLOCKED</small><b>${a.name}</b></div>`;document.body.appendChild(d);requestAnimationFrame(()=>d.classList.add("show"));setTimeout(()=>{d.classList.remove("show");setTimeout(()=>d.remove(),400)},3200)}

/* ---------- Core: XP + achievements ---------- */
function unlockAch(id,delay=0){if(g.ach[id])return;const a=ACH.find(x=>x.id===id);if(!a)return;g.ach[id]=Date.now();save();setTimeout(()=>{sfx("achievement");badgeToast(a)},delay)}
function addXP(n,label,{quiet=false}={}){
 const before=levelInfo().level;g.xp+=n;save();
 const after=levelInfo().level;
 if(!quiet){floatText(`+${n} XP${label?" · "+label:""}`);sfx("xp")}
 refreshHud();
 if(after>before){setTimeout(()=>levelUp(after),quiet?0:500)}
 if(after>=5)unlockAch("lvl5",900);
}
let pendingLevel=0;
function levelUp(l){
 if(Game._after){pendingLevel=l;return}
 sfx("level");confetti(120);
 const o=overlay(`<div class="reveal-box levelup"><div class="reveal-kicker">LEVEL UP!</div><div class="lvl-big">${l}</div><p class="muted">You're climbing the collector ranks.</p><button class="btn primary" onclick="Game.closeOverlay()">Keep going</button></div>`);
 o.dataset.kind="levelup";
}
function bump(k,by=1){g.stats[k]=stat(k)+by;save()}

/* ---------- Overlay ---------- */
function overlay(html){document.querySelectorAll(".game-overlay").forEach(o=>o.remove());const o=document.createElement("div");o.className="game-overlay";o.innerHTML=html;document.body.appendChild(o);requestAnimationFrame(()=>o.classList.add("show"));return o}
function closeOverlay(){document.querySelectorAll(".game-overlay").forEach(o=>{o.classList.remove("show");setTimeout(()=>o.remove(),250)});const f=Game._after;Game._after=null;if(f)f();if(pendingLevel){const l=pendingLevel;pendingLevel=0;setTimeout(()=>levelUp(l),450)}}

/* ---------- Listing power meter (create form) ---------- */
const CHECKS=[
 {k:"photo",label:"Photo",pts:30,ok:()=>!!window.__photo||((document.getElementById("photo")||{}).files||[]).length>0},
 {k:"name",label:"Card name",pts:15,ok:()=>v("name")},
 {k:"set",label:"Set",pts:10,ok:()=>v("set")},
 {k:"price",label:"Price",pts:15,ok:()=>Number(v("price"))>0},
 {k:"wants",label:"I want",pts:15,ok:()=>v("wants")},
 {k:"desc",label:"Description",pts:15,ok:()=>v("desc")}
];
function v(id){const e=document.getElementById(id);return e&&e.value.trim().length>0}
function powerScore(){return CHECKS.reduce((s,c)=>s+(c.ok()?c.pts:0),0)}
let metered={};
function meterHTML(){return `<div id="powerMeter" class="power"><div class="power-top"><b>LISTING POWER</b><span id="powerTier" class="tier common">COMMON</span><span id="powerPct" class="power-pct">0%</span></div><div class="power-bar"><i id="powerFill"></i></div><div id="powerChecks" class="power-checks">${CHECKS.map(c=>`<span data-k="${c.k}">${c.label}</span>`).join("")}</div><div class="muted power-hint">Fill everything in to reveal a Legendary listing.</div></div>`}
function updateMeter(){
 const m=document.getElementById("powerMeter");if(!m)return;
 const p=powerScore(),t=tierFor(p);let done=0;
 CHECKS.forEach(c=>{const on=c.ok(),el=m.querySelector(`[data-k="${c.k}"]`);if(el)el.classList.toggle("on",on);if(on){done++;if(!metered[c.k]){metered[c.k]=1;if(c.k!=="photo")sfx("tick",done)}}else metered[c.k]=0});
 document.getElementById("powerFill").style.width=p+"%";
 document.getElementById("powerPct").textContent=p+"%";
 const te=document.getElementById("powerTier");te.textContent=t.name;te.className="tier "+t.cls;
 m.className="power "+t.cls;
 if(p===100&&!metered.__full){metered.__full=1;sfx("coin");const r=m.getBoundingClientRect();confetti(50,{x:r.left+r.width/2,y:r.top});}
 if(p<100)metered.__full=0;
}
function mountCreate(){
 metered={};
 const btn=document.querySelector("form.form-grid button[type=submit]");
 if(btn&&!document.getElementById("powerMeter")){btn.insertAdjacentHTML("beforebegin",meterHTML())}
 const form=document.querySelector("form.form-grid");
 if(form){["input","change"].forEach(ev=>form.addEventListener(ev,updateMeter));
  form.querySelectorAll("select,button").forEach(el=>el.addEventListener("pointerdown",()=>sfx("click")))}
 updateMeter();
}
function onPhoto(count=1){
 sfx("photo");bump("photos",count);
 addXP(10*Math.min(count,3),count>1?count+" photos":"photo");
 unlockAch("photo",600);
 setTimeout(updateMeter,0);
}

/* ---------- Listing created: the big moment ---------- */
function onListingCreated(x,proceed){
 const p=powerScore(),t=tierFor(p);
 const xp=20+Math.round(p*.6);
 bump("listings");
 Game._after=proceed;
 const bonusStreak=0;
 const html=`<div class="reveal-box"><div class="reveal-kicker">LISTING CREATED</div>
  <div class="reveal-card ${t.cls}"><div class="shine"></div><div class="rc-tier">${t.name}</div>
  <div class="rc-photo">${x.photo?`<img src="${x.photo}" alt="">`:`<span>🃏</span>`}</div>
  <div class="rc-name">${esc(x.name)}</div><div class="rc-sub">${esc(x.set)} · ${esc(x.condition)}</div></div>
  <div class="reveal-xp">+${xp} XP</div><div class="muted">Listing power ${p}%</div>
  <button class="btn primary" onclick="Game.closeOverlay()">View my listing →</button></div>`;
 overlay(html);
 sfx(t.cls==="legendary"?"legendary":"success");
 confetti(t.cls==="legendary"?260:t.cls==="epic"?180:110);
 addXP(xp,"",{quiet:true});
 const n=stat("listings");
 unlockAch("first_listing",1200);
 if(p===100)unlockAch("legendary",1800);
 if(n>=3)unlockAch("three",2400);
 if(n>=10)unlockAch("ten",2400);
}

/* ---------- Other hooks ---------- */
function onWant(){bump("wants");addXP(10,"new want");sfx("coin");unlockAch("hunter",600)}
function onShare(){bump("shares");addXP(8,"shared");sfx("coin");unlockAch("hype",600)}
function onOffer(){addXP(5,"offer");}

/* ---------- Daily streak ---------- */
function touchDay(){
 const today=new Date().toISOString().slice(0,10);if(g.lastDay===today)return;
 const y=new Date(Date.now()-864e5).toISOString().slice(0,10);
 g.streak=g.lastDay===y?g.streak+1:1;g.lastDay=today;save();
 g.xp+=5;save();
 setTimeout(()=>{if(document.body){floatText(`Daily visit +5 XP${g.streak>1?" · 🔥 "+g.streak+"-day streak":""}`);refreshHud()}},700);
 if(g.streak>=3)unlockAch("streak3",1500);
}

/* ---------- Profile panel ---------- */
function profilePanel(){
 const L=levelInfo(),got=Object.keys(g.ach).length;
 return `<section class="panel game-panel"><div class="gp-top"><div class="gp-lvl">LV ${L.level}</div><div style="flex:1"><div class="gp-xp"><b>${g.xp} XP</b><span class="muted">${L.into}/${L.span} to level ${L.level+1}</span></div><div class="power-bar"><i style="width:${L.pct}%"></i></div></div><div class="gp-streak">🔥 <b>${g.streak||0}</b><small>day streak</small></div></div>
 <div class="section-head" style="margin:20px 0 10px"><h2 style="font-size:18px">Achievements</h2><span class="muted">${got}/${ACH.length}</span></div>
 <div class="ach-grid">${ACH.map(a=>`<div class="ach ${g.ach[a.id]?"got":""}"><span>${g.ach[a.id]?a.icon:"🔒"}</span><b>${a.name}</b><small>${a.desc}</small></div>`).join("")}</div></section>`;
}

touchDay();
return{hud,refreshHud,toggleMute,sfx,confetti,addXP,mountCreate,refreshMeter:updateMeter,onPhoto,onListingCreated,onWant,onShare,onOffer,profilePanel,closeOverlay,_after:null};
})();
