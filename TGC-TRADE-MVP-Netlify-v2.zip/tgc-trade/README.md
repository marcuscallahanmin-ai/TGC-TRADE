# TGC TRADE MVP

A static, Netlify-ready MVP for TGC TRADE.

## What is included
- Home/dashboard
- Marketplace with search and filters
- Multi-field card listing form
- Photo upload preview
- Automatic polished social/share card
- Listing detail pages
- My Wants
- Potential trade matching
- Collector profile
- Local browser persistence with localStorage
- Share/copy listing link
- Responsive mobile layout
- Game layer: synthesized sound effects, XP, levels, daily streaks, achievements, listing-power meter, card-rarity reveal on posting, confetti (see game.js / game.css)

## Run locally
You can simply open `index.html` in a browser, or serve the folder with any static server.

## Deploy to Netlify
Drag the `tgc-trade` folder into Netlify's deploy area, or connect the folder/repository.

## What changed in v2
- Removed all demo listings and the fake "Marcus" profile; first visit asks you to set up your collector profile.
- Every section works: Marketplace (search, filters, sort), multi-photo listings (auto-compressed), listing page with Mark sold / Delete, My Wants (add/remove, live matches), Find My Trade (mutual / you-want / they-want matching), Offers (offer composer + status tracker), Profile (edit, XP, reset).
- Share links now carry the listing itself: anyone who opens one can tap "Save to my marketplace" (photos are not included in links).
- Offers copy your message and open the seller's contact (Messenger link, @username or number) because there is no backend chat yet.
- Old v1 data is migrated automatically (demo cards dropped, your own kept).

## Important MVP note
This is a front-end MVP. Listings and profile data are stored in the browser only. The next production phase should add a real database, user accounts, image storage, real messaging, moderation/reporting, and server-side matching.

TGC TRADE is an independent platform and is not affiliated with Pokémon or Nintendo.


## Game layer notes
- All sounds are synthesized with the Web Audio API, so there are no audio files to host. Browsers only allow audio after a first click or tap, so the first sound plays after the user's first interaction.
- A 🔊 button in the header mutes or unmutes (saved in the browser).
- XP, level, streak and achievements are stored in localStorage (key `tgc_trade_game_v1`). Like the listings, this is browser-only and not tamper-proof; move it server-side with accounts in the production phase.
