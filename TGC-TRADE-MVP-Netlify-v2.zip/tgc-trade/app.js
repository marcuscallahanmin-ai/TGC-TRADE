const KEY="tgc_trade_v2";
const uid=()=>Math.random().toString(36).slice(2,10)+Date.now().toString(36);
function load(){
 try{const s=JSON.parse(localStorage.getItem(KEY)||"null");if(s)return s}catch(e){}
 const st={listings:[],wants:[],offers:[],profile:{id:uid(),name:"",location:"",contact:""}};
 try{const o=JSON.parse(localStorage.getItem("tgc_trade_v1")||"null");if(o){ // migrate v1: drop old demo data, keep your own
  const mine=(o.listings||[]).filter(x=>x.id>4);
  st.listings=mine.map(x=>({...x,sellerId:st.profile.id,photos:x.photo?[x.photo]:[],contact:""}));
  if(mine.length){st.profile.name=o.profile?.name||"";st.profile.location=o.profile?.location||""}
  const w=o.wants||[];if(!(w.length===2&&w[0]==="Umbreon"&&w[1]==="Eevee"))st.wants=w}}catch(e){}
 return st}
let state=load();
function save(){try{localStorage.setItem(KEY,JSON.stringify(state));return true}catch(e){toast("Storage is full — use fewer/smaller photos or delete a listing.");return false}}
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
const money=n=>n?`₱${Number(n).toLocaleString()}`:"Trade";
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove("show"),2600)}
const initials=n=>(n||"?").split(/\s+/).map(x=>x[0]).join("").slice(0,2).toUpperCase();
const isMine=x=>x.sellerId===state.profile.id;
const cover=x=>(x.photos&&x.photos[0])||x.photo||"";
const norm=s=>(s||"").toLowerCase();
const terms=s=>norm(s).split(/[,;\n]+/).map(t=>t.trim()).filter(t=>t.length>1);
const hasTerm=(text,list)=>{const t=norm(text);return list.some(w=>t.includes(w))};
const tagCls=m=>m==="Trade"?"trade":m==="Sale"?"sale":"";
function contactHref(c){c=(c||"").trim();if(!c)return"";if(/^https?:\/\//i.test(c))return c;if(/^[\d+][\d\s-]{6,}$/.test(c))return"sms:"+c.replace(/\s/g,"");if(/^@?[\w.]{3,}$/.test(c))return"https://m.me/"+c.replace("@","");return""}

/* ---------- modal ---------- */
function closeModal(){document.querySelectorAll(".modal").forEach(m=>m.remove())}
function modal(html){closeModal();const m=document.createElement("div");m.className="modal";m.innerHTML=`<div class="modal-box">${html}</div>`;m.addEventListener("pointerdown",e=>{if(e.target===m)closeModal()});document.body.appendChild(m);const f=m.querySelector("input,textarea,select");if(f)f.focus()}
function profileModal(first){modal(`<form onsubmit="saveProfile(event)" class="form-grid"><h2 style="margin:0">${first?"Welcome, collector 👋":"Edit profile"}</h2><div class="muted">${first?"Set up your collector profile to start listing and trading.":"Update how other collectors see you."}</div>
<div><label class="label">Collector name</label><input id="pf_name" class="field" required value="${esc(state.profile.name)}" placeholder="e.g. Marcus"></div>
<div><label class="label">City / area</label><input id="pf_loc" class="field" value="${esc(state.profile.location)}" placeholder="e.g. Taguig"></div>
<div><label class="label">Contact (Messenger link, @username or mobile number)</label><input id="pf_contact" class="field" value="${esc(state.profile.contact)}" placeholder="https://m.me/yourname"></div>
<div style="display:flex;gap:8px"><button class="btn primary" type="submit">Save</button>${first?"":`<button class="btn" type="button" onclick="closeModal()">Cancel</button>`}</div></form>`)}
function saveProfile(e){e.preventDefault();const p=state.profile;p.name=pf_name.value.trim();p.location=pf_loc.value.trim();p.contact=pf_contact.value.trim();
 state.listings.forEach(x=>{if(isMine(x)){x.seller=p.name;x.avatar=initials(p.name);x.location=p.location||x.location;x.contact=p.contact}});
 save();closeModal();toast("Profile saved");render()}
function needProfile(){if(state.profile.name)return true;profileModal(true);return false}

/* ---------- layout ---------- */
function nav(a){const L=(k,h,t)=>`<a class="${a===k?"active":""}" href="#/${h}">${t}</a>`;
 return `<header class="topbar"><div class="topbar-inner"><a class="logo" href="#/"><span>TGC</span> TRADE</a><nav class="nav">${L("home","","Home")}${L("market","market","Marketplace")}${L("create","create","+ List")}${L("matches","matches","Find My Trade")}${L("wants","wants","My Wants")}${L("offers","offers","Offers")}${L("profile","profile","Profile")}</nav><div class="header-actions"><a class="btn primary small" href="#/create">List a Card</a><div class="hud-wrap">${Game.hud()}</div><a class="avatar" href="#/profile">${initials(state.profile.name)}</a></div></div></header>`}
function layout(c,a="home"){document.getElementById("app").innerHTML=`<div class="shell">${nav(a)}<main>${c}</main><footer class="footer">TGC TRADE · Buy · Sell · Trade · Match<br><span>Independent community platform. Not affiliated with Pokémon or Nintendo.</span></footer></div>`}
const img=(x,emoji="🃏")=>cover(x)?`<img src="${cover(x)}" alt="${esc(x.name)}">`:`<div class="placeholder">${emoji}</div>`;
function listingCard(x){const mine=isMine(x);return `<article class="card"><div class="card-img" onclick="viewListing('${x.id}')" style="cursor:pointer">${img(x)}${x.sold?`<span class="sold-badge">SOLD</span>`:""}</div><div class="card-body"><span class="tag ${tagCls(x.mode)}">${esc(x.mode)}</span>${mine?` <span class="tag">YOURS</span>`:""}<h3>${esc(x.name)}</h3><div class="muted">${esc(x.set)} · ${esc(x.condition)}</div><div class="card-foot"><span>${esc(x.location||"Philippines")}</span><span class="price">${money(x.price)}</span></div><div class="card-actions"><button class="btn small" onclick="viewListing('${x.id}')">${mine?"Manage":"View"}</button>${mine?"":`<button class="btn success small" onclick="offer('${x.id}')">${x.mode==="Sale"?"Message":"Make Offer"}</button>`}</div></div></article>`}
const emptyCta=(t,b,h)=>`<div class="empty" style="grid-column:1/-1">${t}<br><br><a class="btn primary" href="#/${h}">${b}</a></div>`;

/* ---------- matching ---------- */
function findMatches(){
 const mine=state.listings.filter(x=>isMine(x)&&!x.sold),others=state.listings.filter(x=>!isMine(x)&&!x.sold),mw=state.wants.map(norm),out=[];
 others.forEach(o=>{const ot=terms(o.wants),oText=o.name+" "+o.set;let mutual=null;
  mine.forEach(m=>{if(!mutual&&hasTerm(m.name+" "+m.set,ot)&&hasTerm(oText,[...mw,...terms(m.wants)]))mutual=m});
  if(mutual)out.push({kind:"mutual",me:mutual,other:o});
  else if(hasTerm(oText,mw))out.push({kind:"want",other:o});
  else{const m=mine.find(m=>hasTerm(m.name+" "+m.set,ot));if(m)out.push({kind:"interest",me:m,other:o})}});
 return out.sort((a,b)=>["mutual","want","interest"].indexOf(a.kind)-["mutual","want","interest"].indexOf(b.kind))}

/* ---------- pages ---------- */
function home(){
 const live=state.listings.filter(x=>!x.sold),latest=live.slice().reverse().slice(0,4);
 layout(`<section class="hero"><div class="hero-card"><div class="tag">THE COLLECTOR MARKETPLACE</div><h1>SHOW WHAT YOU <span class="gradient">HAVE.</span><br>FIND WHAT YOU <span class="gradient">WANT.</span></h1><p>TGC TRADE takes the things collectors already do on Facebook—post, search, sell, trade, message—and builds a card-first experience around them.</p><div class="hero-buttons"><a class="btn primary" href="#/create">📸 Create a Listing</a><a class="btn" href="#/matches">🤝 Find My Trade</a></div></div><div class="hero-card"><div class="section-head"><h2>Your activity</h2></div><div class="stats"><div class="stat"><b>${live.length}</b><span>Live listings</span></div><div class="stat"><b>${state.wants.length}</b><span>Your wants</span></div><div class="stat"><b>${findMatches().length}</b><span>Trade matches</span></div><div class="stat"><b>${state.offers.length}</b><span>Offers sent</span></div></div><div style="margin-top:16px" class="muted">Post a listing, add your wants, then share links so other collectors can save your listing to their marketplace.</div></div></section>
<section class="section-head"><div><h2>🔥 Fresh listings</h2><div class="muted">Listings ready for sale or trade</div></div><a class="btn small" href="#/market">See all</a></section><div class="grid">${latest.map(listingCard).join("")||emptyCta("No listings yet. Be the first to post a card.","📸 Create a Listing","create")}</div>`);
}
function market(){
 layout(`<section class="section-head"><div><h2>Marketplace</h2><div class="muted">Search cards, collectors and opportunities.</div></div><a class="btn primary" href="#/create">+ List a Card</a></section>
<div class="controls"><input id="q" class="search" placeholder="Search Charizard, Umbreon, 151..." oninput="filterMarket()"><select id="mkMode" class="field" onchange="filterMarket()"><option>All</option><option>Sale</option><option>Trade</option><option>Both</option></select><select id="cond" class="field" onchange="filterMarket()"><option>Any condition</option><option>Near Mint</option><option>Lightly Played</option><option>Moderately Played</option><option>Heavily Played</option><option>Sealed</option></select><select id="sort" class="field" onchange="filterMarket()"><option value="new">Newest</option><option value="lo">Price: low to high</option><option value="hi">Price: high to low</option></select></div>
<div id="marketGrid" class="grid"></div>`);filterMarket();
}
function filterMarket(){
 const q=norm($("q").value),m=$("mkMode").value,c=$("cond").value,s=$("sort").value;
 let arr=state.listings.filter(x=>!x.sold&&(!q||norm([x.name,x.set,x.location,x.seller,x.wants].join(" ")).includes(q))&&(m==="All"||x.mode===m)&&(c==="Any condition"||x.condition===c));
 arr=s==="lo"?arr.sort((a,b)=>a.price-b.price):s==="hi"?arr.sort((a,b)=>b.price-a.price):arr.slice().reverse();
 document.getElementById("marketGrid").innerHTML=arr.length?arr.map(listingCard).join(""):state.listings.length?`<div class="empty" style="grid-column:1/-1">No listings match your search.</div>`:emptyCta("The marketplace is empty. Post the first card!","📸 Create a Listing","create");
}
function create(){
 if(!state.profile.name)profileModal(true);window.__photos=[];window.__photo="";
 layout(`<section class="section-head"><div><h2>Create your TGC TRADE listing</h2><div class="muted">Make it once. Use it on TGC TRADE and share it to Facebook.</div></div></section>
<div class="two"><form class="panel form-grid" onsubmit="createListing(event)"><div><label class="label">Card photos (up to 5)</label><div class="drop"><input id="photo" type="file" accept="image/*" multiple><div class="muted" style="margin-top:8px">Front, back, or a whole collection.</div></div></div>
<div><label class="label">Card / collection name</label><input id="name" class="field" required placeholder="e.g. Charizard ex"></div>
<div><label class="label">Set</label><input id="set" class="field" placeholder="e.g. 151, Evolving Skies"></div>
<div class="two"><div><label class="label">Price (PHP)</label><input id="price" class="field" type="number" min="0" placeholder="4500"></div><div><label class="label">Condition</label><select id="condition" class="field"><option>Near Mint</option><option>Lightly Played</option><option>Moderately Played</option><option>Heavily Played</option><option>Sealed</option></select></div></div>
<div><label class="label">Listing type</label><select id="mode" class="field"><option>Both</option><option>Sale</option><option>Trade</option></select></div>
<div><label class="label">What are you looking for? (separate with commas)</label><input id="wants" class="field" placeholder="Umbreon, Charizard, vintage..."></div>
<div><label class="label">Description</label><textarea id="desc" class="field textarea" placeholder="Tell collectors what makes this listing worth a look."></textarea></div>
<button class="btn primary" type="submit">✨ Create Listing</button></form>
<div class="panel preview"><div id="preview" class="share-card"><div class="share-brand">TGC TRADE · FOR SALE / TRADE</div><div class="share-title" id="pname">YOUR CARD</div><div class="share-photo" id="pphoto"><span class="placeholder">🃏</span></div><div class="share-meta"><div><div class="muted">PRICE</div><div class="share-price" id="pprice">₱—</div></div><div style="text-align:right"><div class="muted">CONDITION</div><b id="pcond">Near Mint</b></div></div><div class="share-bottom">TGC TRADE · SHOW WHAT YOU HAVE. FIND WHAT YOU WANT.</div></div></div></div>`);
 ["name","price","condition"].forEach(id=>document.getElementById(id).addEventListener("input",updatePreview));
 Game.mountCreate();
 document.getElementById("photo").addEventListener("change",async e=>{const fs=[...e.target.files].slice(0,5);if(!fs.length)return;
  const ph=(await Promise.all(fs.map(shrink))).filter(Boolean);if(!ph.length)return toast("Couldn't read that image.");
  window.__photos=ph;window.__photo=ph[0];document.getElementById("pphoto").innerHTML=`<img src="${ph[0]}" alt="preview">`;Game.onPhoto(ph.length);Game.refreshMeter()});
}
function shrink(file){return new Promise(res=>{const r=new FileReader();r.onload=()=>{const i=new Image();i.onload=()=>{const s=Math.min(1,900/Math.max(i.width,i.height)),c=document.createElement("canvas");c.width=Math.round(i.width*s);c.height=Math.round(i.height*s);c.getContext("2d").drawImage(i,0,0,c.width,c.height);res(c.toDataURL("image/jpeg",.8))};i.onerror=()=>res("");i.src=r.result};r.onerror=()=>res("");r.readAsDataURL(file)})}
const $=id=>document.getElementById(id);
function updatePreview(){$("pname").textContent=$("name").value||"YOUR CARD";$("pprice").textContent=money($("price").value);$("pcond").textContent=$("condition").value}
function createListing(e){e.preventDefault();if(!needProfile())return;const p=state.profile;
 const x={id:uid(),created:Date.now(),name:$("name").value.trim(),set:$("set").value.trim()||"TCG",price:Number($("price").value)||0,mode:$("mode").value,condition:$("condition").value,location:p.location||"Philippines",seller:p.name,sellerId:p.id,avatar:initials(p.name),contact:p.contact,photos:window.__photos||[],description:$("desc").value.trim(),wants:$("wants").value.trim(),sold:false};
 state.listings.push(x);if(!save()){state.listings.pop();return}
 window.__photos=[];window.__photo="";Game.onListingCreated({...x,photo:cover(x)},()=>{location.hash=`#/listing/${x.id}`})}
function viewListing(id){location.hash=`#/listing/${id}`}
function listing(id,shared){
 const x=shared||state.listings.find(a=>a.id==id);if(!x){toast("Listing not found.");return home()}
 const mine=!shared&&isMine(x),ph=x.photos&&x.photos.length?x.photos:(x.photo?[x.photo]:[]),href=contactHref(x.contact);
 layout(`<section class="two"><div class="panel"><div class="card-img big" style="height:480px;border-radius:15px">${ph.length?`<img id="mainPhoto" src="${ph[0]}" alt="${esc(x.name)}">`:`<div class="placeholder">🃏</div>`}${x.sold?`<span class="sold-badge">SOLD</span>`:""}</div>${ph.length>1?`<div class="thumbs">${ph.map(p=>`<img src="${p}" onclick="document.getElementById('mainPhoto').src=this.src" alt="">`).join("")}</div>`:""}${shared?"":""}</div>
<div class="panel"><span class="tag ${tagCls(x.mode)}">${esc(x.mode)}</span><h1 style="font-size:42px;line-height:1;margin:13px 0">${esc(x.name)}</h1><div class="muted">${esc(x.set)} · ${esc(x.condition)} · ${esc(x.location||"Philippines")}</div><div class="price" style="font-size:34px;margin:22px 0">${money(x.price)}</div><p style="line-height:1.7;color:#c4ccd8">${esc(x.description||"No description yet.")}</p><div class="panel" style="padding:14px;margin:18px 0;background:#0d1219"><b>I WANT</b><div class="muted" style="margin-top:5px">${esc(x.wants||"Open to offers")}</div></div>
<div style="display:flex;gap:9px;flex-wrap:wrap">${shared?`<button class="btn success" onclick="saveShared()">➕ Save to my marketplace</button>`:mine?`<button class="btn" onclick="toggleSold('${x.id}')">${x.sold?"↩ Mark available":"✅ Mark as sold/traded"}</button><button class="btn" onclick="delListing('${x.id}')" style="color:var(--danger)">🗑 Delete</button>`:`<button class="btn success" onclick="offer('${x.id}')">💬 ${x.mode==="Sale"?"Message Seller":"Make Trade Offer"}</button>`}${shared?"":`<button class="btn" onclick="shareListing('${x.id}')">📤 Share</button><button class="btn" onclick="fbShare('${x.id}')">Facebook</button>`}</div>
<div style="margin-top:22px" class="muted">Seller · <b style="color:var(--text)">${esc(x.seller)}</b>${href&&!mine?` · <a href="${esc(href)}" target="_blank" rel="noopener" style="color:var(--accent2)">Contact</a>`:""}</div></div></section>`,"market")}
function toggleSold(id){const x=state.listings.find(a=>a.id==id);if(!x)return;x.sold=!x.sold;save();toast(x.sold?"Marked as sold — removed from the marketplace.":"Back on the marketplace.");listing(id)}
function delListing(id){if(!confirm("Delete this listing?"))return;state.listings=state.listings.filter(a=>a.id!=id);save();toast("Listing deleted");location.hash="#/profile"}

/* ---------- share ---------- */
function shareUrl(x){const o={n:x.name,s:x.set,p:x.price,m:x.mode,c:x.condition,l:x.location,u:x.seller,i:x.sellerId,k:x.contact,d:x.description,w:x.wants,t:x.created||0};
 return location.origin+location.pathname+"#/shared/"+btoa(unescape(encodeURIComponent(JSON.stringify(o)))).replace(/\+/g,"-").replace(/\//g,"_")}
let sharedItem=null;
function sharedView(p){try{const o=JSON.parse(decodeURIComponent(escape(atob(p.replace(/-/g,"+").replace(/_/g,"/")))));
 sharedItem={id:"shared",name:o.n,set:o.s,price:o.p,mode:o.m,condition:o.c,location:o.l,seller:o.u,sellerId:o.i,contact:o.k,description:o.d,wants:o.w,created:o.t,photos:[],sold:false};listing(null,sharedItem)}catch(e){toast("That share link looks broken.");home()}}
function saveShared(){const x=sharedItem;if(!x)return;if(x.sellerId===state.profile.id)return toast("That's your own listing.");
 const dup=state.listings.find(a=>a.sellerId===x.sellerId&&a.created===x.created&&a.name===x.name);if(dup){location.hash=`#/listing/${dup.id}`;return}
 const n={...x,id:uid()};state.listings.push(n);if(save()){toast("Saved to your marketplace");location.hash=`#/listing/${n.id}`}}
async function shareListing(id){const x=state.listings.find(a=>a.id==id);if(!x)return;const url=shareUrl(x),text=`${x.name} — ${money(x.price)} · ${x.mode}\n${x.description||""}`;
 if(navigator.share){try{await navigator.share({title:`${x.name} · TGC TRADE`,text,url});Game.onShare();return}catch(e){if(e.name==="AbortError")return}}
 try{await navigator.clipboard.writeText(`${text}\n${url}`);toast("Listing text + link copied — paste it anywhere.")}catch(e){prompt("Copy this link:",url)}Game.onShare()}
function fbShare(id){const x=state.listings.find(a=>a.id==id);if(!x)return;window.open("https://www.facebook.com/sharer/sharer.php?u="+encodeURIComponent(shareUrl(x)),"_blank","noopener");Game.onShare()}

/* ---------- offers ---------- */
function offer(id){
 const x=state.listings.find(a=>a.id==id);if(!x)return;if(isMine(x))return toast("That's your own listing.");if(!needProfile())return;
 const mine=state.listings.filter(a=>isMine(a)&&!a.sold),canTrade=x.mode!=="Sale";
 modal(`<form onsubmit="sendOffer(event,'${x.id}')" class="form-grid"><h2 style="margin:0">${x.mode==="Sale"?"Message":"Offer to"} ${esc(x.seller)}</h2><div class="muted">${esc(x.name)} · ${money(x.price)}</div>
${canTrade&&mine.length?`<div><label class="label">Offer one of your cards (optional)</label><select id="of_card" class="field"><option value="">— cash only / just a message —</option>${mine.map(m=>`<option value="${m.id}">${esc(m.name)}</option>`).join("")}</select></div>`:""}
<div><label class="label">Cash (PHP, optional)</label><input id="of_cash" class="field" type="number" min="0" placeholder="${x.price||""}"></div>
<div><label class="label">Message</label><textarea id="of_msg" class="field textarea" placeholder="Hi! Is this still available?"></textarea></div>
<div class="muted" style="font-size:12px">Your message is copied to the clipboard and the seller's contact opens${contactHref(x.contact)?"":" (they didn't add a contact link — paste it wherever you chat)"}.</div>
<div style="display:flex;gap:8px"><button class="btn success" type="submit">Send offer</button><button class="btn" type="button" onclick="closeModal()">Cancel</button></div></form>`)}
function sendOffer(e,id){e.preventDefault();const x=state.listings.find(a=>a.id==id);if(!x)return;
 const card=document.getElementById("of_card"),c=card&&state.listings.find(a=>a.id==card.value),cash=Number(of_cash.value)||0;
 const parts=[`Hi ${x.seller}, I'm ${state.profile.name} on TGC TRADE. I'm interested in your ${x.name}.`];
 if(c)parts.push(`I can offer my ${c.name}${cash?` + ${money(cash)}`:""}.`);else if(cash)parts.push(`I can offer ${money(cash)}.`);
 if(of_msg.value.trim())parts.push(of_msg.value.trim());
 const text=parts.join(" ");
 state.offers.push({id:uid(),listingId:x.id,listing:x.name,seller:x.seller,contact:x.contact,text,status:"Sent",date:Date.now()});
 if(!save())return;closeModal();Game.onOffer();
 navigator.clipboard?.writeText(text).catch(()=>{});const h=contactHref(x.contact);if(h)window.open(h,"_blank","noopener");
 toast("Offer saved & copied — paste it in your chat with "+x.seller);}
function offers(){
 const list=state.offers.slice().reverse();
 layout(`<section class="section-head"><div><h2>💬 Offers</h2><div class="muted">Offers and messages you've sent. Update the status as your deals progress.</div></div></section>
<div class="matches">${list.map(o=>`<div class="match" style="grid-template-columns:1fr auto"><div class="person"><b>${esc(o.listing)} <span class="muted">· ${esc(o.seller)}</span></b><div class="muted" style="margin:6px 0">${esc(o.text)}</div><small class="muted">${new Date(o.date).toLocaleDateString()}</small></div><div style="display:grid;gap:7px"><select class="field" onchange="setOffer('${o.id}',this.value)">${["Sent","Accepted","Declined","Completed"].map(s=>`<option ${s===o.status?"selected":""}>${s}</option>`).join("")}</select><button class="btn small" onclick="copyOffer('${o.id}')">Copy</button><button class="btn small" onclick="delOffer('${o.id}')">Remove</button></div></div>`).join("")||`<div class="empty">No offers yet. Open a listing and tap “Make Offer”.<br><br><a class="btn primary" href="#/market">Browse marketplace</a></div>`}</div>`,"offers")}
function setOffer(id,s){const o=state.offers.find(a=>a.id==id);if(o){o.status=s;save();if(s==="Completed")Game.addXP(15,"deal done")}}
function delOffer(id){state.offers=state.offers.filter(a=>a.id!=id);save();offers()}
function copyOffer(id){const o=state.offers.find(a=>a.id==id);navigator.clipboard?.writeText(o.text).then(()=>toast("Copied"),()=>prompt("Copy:",o.text))}

/* ---------- wants / matches / profile ---------- */
function wants(){
 const mw=state.wants.map(norm),hits=state.listings.filter(x=>!isMine(x)&&!x.sold&&hasTerm(x.name+" "+x.set,mw));
 layout(`<section class="section-head"><div><h2>❤️ My Wants</h2><div class="muted">Tell TGC TRADE what you're hunting for.</div></div><button class="btn primary" onclick="addWant()">+ Add a Want</button></section>
<div class="panel"><div style="display:flex;gap:8px;flex-wrap:wrap">${state.wants.map((w,i)=>`<span class="tag" style="font-size:14px;padding:9px 12px">${esc(w)} <button style="border:0;background:transparent;color:#9ca6b5" onclick="removeWant(${i})" aria-label="Remove">×</button></span>`).join("")||`<div class="empty" style="width:100%">Add cards you're hunting for and we'll use them in matching.</div>`}</div></div>
<section class="section-head"><div><h2>Potential matches</h2><div class="muted">Listings that line up with your wants.</div></div></section><div class="grid">${hits.map(listingCard).join("")||`<div class="empty" style="grid-column:1/-1">No direct matches yet. Keep adding wants.</div>`}</div>`,"wants")}
function addWant(){modal(`<form onsubmit="saveWant(event)" class="form-grid"><h2 style="margin:0">Add a want</h2><div class="muted">Card or set name. Separate several with commas.</div><input id="w_in" class="field" required placeholder="Umbreon VMAX, Eevee"><div style="display:flex;gap:8px"><button class="btn primary" type="submit">Add</button><button class="btn" type="button" onclick="closeModal()">Cancel</button></div></form>`)}
function saveWant(e){e.preventDefault();const add=w_in.value.split(",").map(s=>s.trim()).filter(s=>s&&!state.wants.some(w=>norm(w)===norm(s)));if(!add.length){closeModal();return toast("Already on your list.")}
 state.wants.push(...add);save();closeModal();wants();Game.onWant()}
function removeWant(i){state.wants.splice(i,1);save();wants()}
function matches(){
 const m=findMatches(),lab={mutual:["🤝 Perfect trade","They want what you have, you want what they have"],want:["🎯 You want this","Matches your My Wants list"],interest:["👀 They want your card","Their wants match one of your listings"]};
 layout(`<section class="hero-card" style="margin-bottom:22px"><div class="tag">SMART MATCHING</div><h1 style="font-size:45px">Find the person who has <span class="gradient">what you want.</span></h1><p>Matches use your listings, your “I want” lists and your My Wants. Save other collectors' shared listings to your marketplace to see matches.</p></section>
<section class="section-head"><div><h2>🤝 Potential matches</h2><div class="muted">${m.length} found</div></div></section>
<div class="matches">${m.map(r=>`<div class="match"><div class="person">${r.me?`<b>You have</b><div>${esc(r.me.name)}</div><small class="muted">${esc(r.me.set)}</small>`:`<b>You want</b><div>${esc(state.wants.find(w=>hasTerm(r.other.name+" "+r.other.set,[norm(w)]))||"")}</div>`}</div><div class="arrow">↔</div><div class="person"><b>${esc(r.other.seller)} has</b><div>${esc(r.other.name)}</div><small class="muted">${lab[r.kind][0]} · ${money(r.other.price)}</small><div style="display:flex;gap:6px;margin-top:8px"><button class="btn small" onclick="viewListing('${r.other.id}')">View</button><button class="btn success small" onclick="offer('${r.other.id}')">Offer</button></div></div></div>`).join("")||`<div class="empty">No matches yet. Add a listing with an “I want” line, add cards to My Wants, or save a friend's shared listing.<br><br><a class="btn primary" href="#/wants">Add Wants</a></div>`}</div>`,"matches")}
function profile(){
 const mine=state.listings.filter(isMine),p=state.profile;
 layout(`<section class="panel"><div class="profile-head"><div class="big-avatar">${initials(p.name)}</div><div><h1 style="margin:0">${esc(p.name||"New collector")}</h1><div class="muted">📍 ${esc(p.location||"Add your city")} · Collector${p.contact?` · ${esc(p.contact)}`:""}</div></div><button class="btn" style="margin-left:auto" onclick="profileModal()">Edit profile</button></div></section>${Game.profilePanel()}
<section class="section-head"><div><h2>My Listings</h2><div class="muted">${mine.length} posted · ${mine.filter(x=>x.sold).length} sold/traded</div></div><a class="btn primary" href="#/create">+ Add Card</a></section><div class="grid">${mine.slice().reverse().map(listingCard).join("")||emptyCta("You haven't listed anything yet.","📸 Create a Listing","create")}</div>
<section class="section-head"><h2>Data</h2></section><div class="panel"><div class="muted" style="margin-bottom:12px">Everything is stored in this browser only.</div><button class="btn" onclick="resetAll()" style="color:var(--danger)">Reset all TGC TRADE data</button></div>`,"profile")}
function resetAll(){if(!confirm("This deletes all listings, wants, offers, profile and progress in this browser. Continue?"))return;localStorage.removeItem(KEY);localStorage.removeItem("tgc_trade_game_v1");localStorage.removeItem("tgc_trade_v1");location.hash="#/";location.reload()}

function render(){closeModal();const p=location.hash.slice(2)||"/";window.scrollTo(0,0);
 if(p==="/")home();else if(p==="/market")market();else if(p==="/create")create();else if(p==="/wants")wants();else if(p==="/matches")matches();else if(p==="/offers")offers();else if(p==="/profile")profile();
 else if(p.startsWith("/listing/"))listing(p.split("/")[2]);else if(p.startsWith("/shared/"))sharedView(p.slice(8));else home();
 if(!state.profile.name&&p==="/"&&!render.asked){render.asked=1;profileModal(true)}}
window.addEventListener("hashchange",render);render();
